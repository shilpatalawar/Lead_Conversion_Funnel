CREATE DATABASE lead_conversion_db;
USE lead_conversion_db;

CREATE TABLE sources (
    source_id INT PRIMARY KEY,
    source_name VARCHAR(100),
    total_leads INT,
    converted_leads INT,
    not_converted_leads INT,
    conversion_rate DECIMAL(5,2)
);

CREATE TABLE leads (
    lead_id INT PRIMARY KEY,
    prospect_id VARCHAR(100),
    lead_number BIGINT,
    lead_origin VARCHAR(100),
    source_id INT,
    FOREIGN KEY (source_id)
        REFERENCES sources(source_id)
);

CREATE TABLE conversions (
    lead_id INT PRIMARY KEY,
    prospect_id VARCHAR(100),
    lead_number BIGINT,
    lead_source VARCHAR(100),
    lead_origin VARCHAR(100),
    converted TINYINT
);

CREATE TABLE lead_activity (
    lead_id INT PRIMARY KEY,
    total_visits INT,
    time_on_website INT,
    page_views_per_visit DECIMAL(10,2),
    FOREIGN KEY (lead_id)
        REFERENCES leads(lead_id)
);


-- Query 1: View lead details using JOIN
-- Combines the four tables to view lead source, conversion status, and website activity together.

SELECT l.lead_id, s.source_name, c.converted,
       a.total_visits, a.time_on_website
FROM leads l
JOIN sources s ON l.source_id = s.source_id
JOIN conversions c ON l.lead_id = c.lead_id
JOIN lead_activity a ON l.lead_id = a.lead_id
LIMIT 10;

-- Query 2: Find the best-converting lead source
-- Calculates total leads, converted leads, and conversion rate for each source.
SELECT s.source_name,
       COUNT(*) AS total_leads,
       SUM(c.converted) AS converted_leads,
       ROUND(100.0 * SUM(c.converted) / COUNT(*), 2)
           AS conversion_rate
FROM leads l
JOIN sources s ON l.source_id = s.source_id
JOIN conversions c ON l.lead_id = c.lead_id
GROUP BY s.source_name
ORDER BY conversion_rate DESC;

-- Query 3: Compare conversion by lead origin
-- Identifies which lead origins have higher conversion rates.
SELECT l.lead_origin,
       COUNT(*) AS total_leads,
       SUM(c.converted) AS converted_leads,
       ROUND(100.0 * SUM(c.converted) / COUNT(*), 2)
           AS conversion_rate
FROM leads l
JOIN conversions c ON l.lead_id = c.lead_id
GROUP BY l.lead_origin
ORDER BY conversion_rate DESC;

-- Query 4: Analyze website engagement
-- Checks whether spending more time on the website is associated with higher conversion.
SELECT
    CASE
        WHEN a.time_on_website < 300 THEN 'Low'
        WHEN a.time_on_website < 1000 THEN 'Medium'
        ELSE 'High'
    END AS engagement_level,
    COUNT(*) AS total_leads,
    ROUND(100.0 * SUM(c.converted) / COUNT(*), 2)
        AS conversion_rate
FROM conversions c
JOIN lead_activity a ON c.lead_id = a.lead_id
GROUP BY engagement_level;

-- Query 5: Calculate source performance using a CTE
-- Uses a CTE (a temporary named result) to calculate conversion rates by source.
WITH source_stats AS (
    SELECT s.source_name,
           COUNT(*) AS total_leads,
           SUM(c.converted) AS converted_leads
    FROM leads l
    JOIN sources s ON l.source_id = s.source_id
    JOIN conversions c ON l.lead_id = c.lead_id
    GROUP BY s.source_name
)
SELECT *,
       ROUND(100.0 * converted_leads / total_leads, 2)
           AS conversion_rate
FROM source_stats;

-- Query 6: Find sources above the average conversion rate
-- Uses a subquery to identify sources performing above the average rate stored in sources.
SELECT source_name, conversion_rate
FROM sources
WHERE conversion_rate > (
    SELECT AVG(conversion_rate)
    FROM sources
)
ORDER BY conversion_rate DESC;

-- Query 7: Rank lead sources
-- Uses a window function to rank sources by conversion rate, highest first.
WITH source_stats AS (
    SELECT s.source_name,
           ROUND(100.0 * SUM(c.converted) / COUNT(*), 2)
               AS conversion_rate
    FROM leads l
    JOIN sources s ON l.source_id = s.source_id
    JOIN conversions c ON l.lead_id = c.lead_id
    GROUP BY s.source_name
)
SELECT source_name, conversion_rate,
       RANK() OVER (ORDER BY conversion_rate DESC) AS source_rank
FROM source_stats;

-- Query 8: Compare each source with the overall conversion rate
-- Shows whether each source performs above or below the overall conversion rate.
SELECT s.source_name,
       s.conversion_rate,
       ROUND(
           100.0 * (SELECT AVG(converted) FROM conversions),
           2
       ) AS overall_conversion_rate
FROM sources s
ORDER BY s.conversion_rate DESC;

-- Query 9: Compare website activity by conversion status
-- Compares average website time and visits for converted and non-converted leads.
SELECT c.converted,
       COUNT(*) AS total_leads,
       ROUND(AVG(a.time_on_website), 2) AS avg_website_time,
       ROUND(AVG(a.total_visits), 2) AS avg_visits
FROM conversions c
JOIN lead_activity a ON c.lead_id = a.lead_id
GROUP BY c.converted;

-- Query 10: Check source summary totals
-- Compares the stored lead totals with actual records to check data consistency.
SELECT s.source_name,
       s.total_leads AS stored_leads,
       COUNT(c.lead_id) AS actual_leads
FROM sources s
LEFT JOIN conversions c ON s.source_name = c.lead_source
GROUP BY s.source_id, s.source_name, s.total_leads;



